//
//  main.m
//  lesson1_exc
//  excersise 1
//
//  Created by english on 2019-09-05.
//  Copyright © 2019 english. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {

        NSLog(@"\n\nIn Objective-C, lowercase letters are significant.\
              \nmain is where program execution begins.\
              \nOpen and closed braces enclose program statements in a\
              \nroutine.\
              \nAll program statements must be terminated by a semicolon.\n\n");
    }
    return 0;
}
